<?php
session_start();
require("include/cufl.php");
if (!empty($_POST['login'])) {
    $cuflObj = new CUFL();
    $result=$cuflObj->addnew($_POST);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>স্মৃতিতে সিইউএফএল এর সদস্য তথ্য</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.standalone.min.css" integrity="sha512-TQQ3J4WkE/rwojNFo6OJdyu6G8Xe9z8rMrlF9y7xpFbQfW5g8aSWcygCQ4vqRiJqFsDsE1T6MoAOMJkFXlrI9A==" crossorigin="anonymous" />
    <link rel="stylesheet" type="text/css" href="assets/css/login.css">

</head>
<body>

<div class="limiter">
    <div class="container-login100">
        <div class="wrap-login100 p-b-160 p-t-50">
            <form class="login100-form validate-form" method="post">
                <div class="login100-form-title p-b-43" style="margin-bottom: 20px;">
                    স্মৃতিতে সি.ইউ.এফ.এল পরিবারের পক্ষ হতে আপনাকে স্বাগতম
                </div>
                <?php if (!empty($result)) { ?>
                    <div <?php if($result['status']) { ?> style="color: green;width: 100%;margin-bottom: 20px;text-align: center;" <?php } else{ ?>style="color: #d0d0d0;width: 100%;margin-bottom: 20px;text-align: center;" <?php } ?>>
                        <?php echo $result['message']; ?>
                    </div>
                <?php } ?>

                <div class="wrap-input100 validate-input" data-validate="name is required" style="width: 100%">
                    <input class="input100" type="text" name="name">
                    <span class="label-input100">Name</span>
                </div>
                <div class="wrap-input100 validate-input" data-validate="email is required" style="width: 100%">
                    <input class="input100" type="text" name="email">
                    <span class="label-input100">Email</span>
                </div>
                <div class="wrap-input100 validate-input" data-validate="mobile is required" style="width: 100%">
                    <input class="input100" type="text" name="mobile">
                    <span class="label-input100">Mobile</span>
                </div>
                <div class="wrap-input100" style="width: 100%">
                    <input class="input100" type="text" name="facebook">
                    <span class="label-input100">Facebook profile name</span>
                </div>
                <div class="wrap-input100 validate-input" data-validate="batch is required" style="width: 100%">
                    <input class="input100" type="text" name="batch">
                    <span class="label-input100">SSC Batch</span>
                </div>
                <div class="wrap-input100 " style="width: 100%">
                    <input class="input100" type="text" name="house_no">
                    <span class="label-input100">House No(CUFL)</span>
                </div>
                <div class="wrap-input100 " style="width: 100%">
                    <input class="input100" type="text" name="address">
                    <span class="label-input100">Current Place</span>
                </div>
                <div class="wrap-input100 " style="width: 100%;">
                    <select class="input100" name="blood" style="border: 0px;">
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                    </select>
                    <span class="label-input100">Blood group</span>
                </div>
                <div class="wrap-input100 " style="width: 100%">
                    <input class="input100" type="text" name="birth" data-provide="datepicker">
                    <span class="label-input100">Date of birth</span>
                </div>
                <div class="container-login100-form-btn">
                    <button class="login100-form-btn" name="login" type="submit" value="login">
                        Be a member
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<script src="assets/js/login.js"></script>

</body>
</html>
