<?php
session_start();
if (empty($_SESSION['username'])) {
    header("Location: login.php");
}
require("DB_CODE/db_connect.php");
require("Classes/PHPExcel/IOFactory.php");

createDatabase();
create_Students_Table();
$conn = OpenCon();

include("Controllers/ExcelImportController.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CUFL-[Excel import]</title>
    <?php include("Controllers/Script&StyleSheetsController.php"); ?>
</head>
<body>
<!-- start top-nav -->
<?php include("templates/topNav.php") ?>
<!-- End top-nav -->
<!-- start body content -->
<br>
<br>
<br>
<br>
<div class="body-content3">
    <div class="uploadBoundary">
        <br>
        <br>
        <br>
        <form action="" method="post" enctype="multipart/form-data">

            <h2>Select An Excel to upload</h2>
            <input type="file" name="fileToUpload" id="fileToUpload">
            <input id="myInput" class="button button3" type="submit" value="Upload Excel" name="submit">
            <p><?php echo $alert; ?></p>
        </form>
    </div>
    <br>
    <br>
    <br>
    <hr>
</div>
</body>
</html>
</div>
<!-- End table -->
</div>
<!-- End -->
<script src="assets/js/customSctipt.js"></script>
</body>
</html>
