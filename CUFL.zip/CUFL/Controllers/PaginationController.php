<?php
// require ("/db_connect.php");
$row_per_page = 150;
$pages_to_click = 5; // 1- 10 options

$page = 1;
$pagi = 1;
if( isset($_GET['page']) ) {
  $page = $_GET['page'];
  $pagi = $_GET['page'];
}

$target_page = 1;
$page == 1 ? $target_page = 1 : $target_page = ( ( $page*$pages_to_click ) - $pages_to_click );
if( isset($_POST["Search_submit"])) {
  $row = $searchRow;
}else {
    $qry_1 = "SELECT * FROM `students_table`";
    $qry_2 = $conn->query($qry_1);

// if(isset($qry_2->num_rows) === True){
    $row = $qry_2->num_rows; //327 rows
}
  $Allpages = ceil($row / $row_per_page);

$target_page -= 1;
$studentsData = $conn->query("SELECT * FROM `students_table` ORDER BY id DESC limit $target_page, $row_per_page");


// echo "<pre>";
// echo "<h1>Present Page : $page</h1><br>";

$page > 1 ? $previousPage = $page - 1 : $previousPage = $page;  //Previous Page
$page < $Allpages ? $nextPage = $page + 1 : $nextPage = $page; //Next Page

$page > 1 ? $page -= 1 : $page;
// }
