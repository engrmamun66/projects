<?php
$searchRow = 0;

$alert = '';


function removeExtraSpace($text)
{
    $text = str_replace("    ", "  ", $text);
    $text = str_replace("   ", "  ", $text);
    $text = str_replace("  ", " ", $text);
    return chop($text);
}


if (isset($_POST["Search_submit"])) {
    $txt_1 = 'SELECT * FROM `students_table` WHERE `id`> 0 ';
    $sortBy = 'name';
    foreach ($_POST as $k => $v) {
        if ($v != 'Search' & strlen($v) > 0) {

            $k == "email" ? $txt_1 = "$txt_1 AND email LIKE '%$v%' " : '';
            $k == "batch" ? $txt_1 = "$txt_1 AND batch ='$v' " : '';
            $k == "name" ? $txt_1 = "$txt_1 AND name LIKE '%$v%' " : '';
            $k == "blood" ? $txt_1 = "$txt_1 AND blood_Group ='$v' " : '';
            $k == "mobile" ? $txt_1 = "$txt_1 AND mobile_no LIKE '%$v%' " : '';
            $k == "address" ? $txt_1 = "$txt_1 AND current_workplace LIKE '%$v%' " : '';
            //$k == "orderby" ? $txt_1 = "$txt_1 ORDER BY $sortBy $v" : '';

        }
    }

// echo "<pre>";

    $txt2 = chop($txt_1);

    $finalText = removeExtraSpace($txt_1); // with removing white space from left and ringt\

    $searchResults = $conn->query($finalText);

// echo "<pre>";
// echo "text1 = ". $txt_1 . "(len : ".strlen($txt_1).")<br>";
// echo $finalText;


    if (isset($searchResults->num_rows)) {
    echo  '.................'.  $searchRow = $searchResults->num_rows;
    } else {
        $searchRow = 0;
    }

}
