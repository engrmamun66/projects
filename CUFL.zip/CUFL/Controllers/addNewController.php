<?php

$alert = '';
if( isset($_POST["StdFormSubmitted"])) {
 // echo "<pre>";
 ! isset( $_POST['email'] ) ? $_POST['email'] = '' : $_POST['email'] = $_POST['email'];
 ! isset( $_POST['name'] ) ? $_POST['name'] = '' : $_POST['name'] = $_POST['name'] ;
 ! isset( $_POST['Facebook_Profile'] ) ? $_POST['Facebook_Profile'] = '' : $_POST['Facebook_Profile']=$_POST['Facebook_Profile'];
 ! isset( $_POST['Batch'] ) ? $_POST['Batch'] = '' : $_POST['Batch'] = $_POST['Batch'];
 ! isset( $_POST['houeNo'] ) ? $_POST['houeNo'] = '': $_POST['houeNo']=$_POST['houeNo'];
 ! isset( $_POST['currentPlace'] ) ? $_POST['currentPlace'] = '' : $_POST['currentPlace']=$_POST['currentPlace'];
 ! isset( $_POST['mobile_no'] ) ? $_POST['mobile_no'] = '': $_POST['mobile_no']=$_POST['mobile_no'];
 ! isset( $_POST['Blood'] ) && $_POST['Blood'] != '0' ? $_POST['Blood'] = '': $_POST['Blood']=$_POST['Blood'];
 ! isset( $_POST['dateOfBirth'] ) ? $_POST['dateOfBirth'] = '' : $_POST['dateOfBirth']=$_POST['dateOfBirth'];

 // print_r($_POST);
$txt = array(
  'email' => $_POST['email'],
  'name' => $_POST['name'],
  'Facebook_Profile' => $_POST['Facebook_Profile'],
  'Batch' => $_POST['Batch'],
  'houeNo' => $_POST['houeNo'],
  'currentPlace' => $_POST['currentPlace'],
  'mobile_no' => $_POST['mobile_no'],
  'Blood' => $_POST['Blood'],
  'dateOfBirth' => $_POST['dateOfBirth'],
  'Created' => date("Y-m-d H:i:s"),
);
extract($txt);
// $conn->query
$queryText= "INSERT INTO `students_table`(`email`, `name`, `fb_id_name`, `batch`, `house_no`, `current_workplace`, `mobile_no`, `blood_Group`, `date_of_birth`, `created`) VALUES('$email', '$name', '$Facebook_Profile', '$Batch', '$houeNo', '$currentPlace', '$mobile_no', '$Blood', '$dateOfBirth', '$Created')";
if ($conn->query($queryText)) {
  $alert = '<span class="alert_suc">Seccessfully Added!</span>';
} else {
  $alert = '<span class="alert_err">Failed To Added!</span>';
}





}
