<div class="" >
  <div class="topnav">
    <a class="active" href="index.php">Home</a>
    <a href="Add_New.php">Add Student</a>
    <a href="Excel-Import.php">Import From Excel</a>
  <input id="togglerBtn" class="togglerUploadSection" value="Toggler" type="submit">
  </div>

</div>
