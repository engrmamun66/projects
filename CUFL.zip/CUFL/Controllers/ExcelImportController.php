<?php
$target_dir = "assets/excel/";

$alert = '';

if(isset($_POST["submit"])) {
  if( isset($_FILES['fileToUpload']) && !empty( $_FILES['fileToUpload']['tmp_name'] ) ) {
    $excelobject = PHPExcel_IOFactory::load( $_FILES['fileToUpload']['tmp_name'] );
    $getSheet = $excelobject->getActiveSheet()->toArray(null);

    for ($i = 1; $i < count($getSheet); $i++) {
      $mail = $getSheet[$i][0];

        $data = [
          'email'             => $getSheet[$i][0],
          'name'              => $getSheet[$i][1],
          'fb_id_name'        => $getSheet[$i][2],
          'batch'             => $getSheet[$i][3],
          'house_no'          => $getSheet[$i][4],
          'current_workplace' => $getSheet[$i][5],
          'mobile_no'         => $getSheet[$i][6],
          'blood_Group'       => $getSheet[$i][7],
          'date_of_birth'     => $getSheet[$i][8],
          'created'           => date("Y-m-d H:i:s")
        ];
        extract($data);
        $querytext = "INSERT INTO `students_table`(`email`, `name`, `fb_id_name`, `batch`, `house_no`, `current_workplace`, `mobile_no`, `blood_Group`, `date_of_birth`, `created`) VALUES ( '$email', '$name', '$fb_id_name', $batch, '$house_no', '$current_workplace', '$mobile_no', '$blood_Group', '$date_of_birth', '$created')";
        if ( $conn->query( $querytext ) ) {
          $alert = '<span class="alert_suc">Import Seccessfully Done! (Total : '. count($getSheet) .')</span>';
        } else {
          $alert = '<span class="alert_err">Excel Import Failed!</span>';
        }

    } // end for loop
  }
}
