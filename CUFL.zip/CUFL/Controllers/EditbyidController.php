<?php

$alert = '';

if( isset( $_GET['id'] ) ) {
  // echo "<pre>";
  // echo $_GET['id'];
  $qtext = "SELECT  * FROM `students_table` WHERE id =" . $_GET['id'];
  $getData = $conn->query($qtext);
  // print_r($getData);
  $DataArray = [];
  foreach($getData as $k => $v){
    $DataArray['id'] = $v['id'];
    $DataArray['email'] = $v['email'];
    $DataArray['name'] = $v['name'];
    $DataArray['fb_id_name'] = $v['fb_id_name'];
    $DataArray['batch'] = $v['batch'];
    $DataArray['house_no'] = $v['house_no'];
    $DataArray['current_workplace'] = $v['current_workplace'];
    $DataArray['mobile_no'] = $v['mobile_no'];
    $DataArray['blood_Group'] = $v['blood_Group'];
    $DataArray['date_of_birth'] = $v['date_of_birth'];
    $DataArray['created'] = $v['created'];
    $DataArray['modified'] = $v['modified'];
  }
// print_r($getData->rows_count);
//   print_r($DataArray);


}



if( isset($_POST["StdFormUpdate"])) {
 // echo "<pre>";
 ! isset( $_POST['email'] ) ? $_POST['email'] = '' : $_POST['email'] = $_POST['email'];
 ! isset( $_POST['name'] ) ? $_POST['name'] = '' : $_POST['name'] = $_POST['name'] ;
 ! isset( $_POST['Facebook_Profile'] ) ? $_POST['Facebook_Profile'] = '' : $_POST['Facebook_Profile']=$_POST['Facebook_Profile'];
 ! isset( $_POST['Batch'] ) ? $_POST['Batch'] = '' : $_POST['Batch'] = $_POST['Batch'];
 ! isset( $_POST['houeNo'] ) ? $_POST['houeNo'] = '': $_POST['houeNo']=$_POST['houeNo'];
 ! isset( $_POST['currentPlace'] ) ? $_POST['currentPlace'] = '' : $_POST['currentPlace']=$_POST['currentPlace'];
 ! isset( $_POST['mobile_no'] ) ? $_POST['mobile_no'] = '': $_POST['mobile_no']=$_POST['mobile_no'];
 ! isset( $_POST['Blood'] ) && $_POST['Blood'] != '0' ? $_POST['Blood'] = '': $_POST['Blood']=$_POST['Blood'];
 ! isset( $_POST['dateOfBirth'] ) ? $_POST['dateOfBirth'] = '' : $_POST['dateOfBirth']=$_POST['dateOfBirth'];

 // print_r($_POST);
$txt = array(
  'id' => $_POST['id'],
  'email' => $_POST['email'],
  'name' => $_POST['name'],
  'Facebook_Profile' => $_POST['Facebook_Profile'],
  'Batch' => $_POST['Batch'],
  'houeNo' => $_POST['houeNo'],
  'currentPlace' => $_POST['currentPlace'],
  'mobile_no' => $_POST['mobile_no'],
  'Blood' => $_POST['Blood'],
  'dateOfBirth' => $_POST['dateOfBirth'],
  'modified' => date("Y-m-d H:i:s"),
);

extract($txt);
// $conn->query
$queryText= "UPDATE `students_table` SET `email` = '$email', `name` = '$name', `fb_id_name` = '$Facebook_Profile', `batch` = '$Batch', `house_no` = '$houeNo', `current_workplace` = '$currentPlace', `mobile_no` = '$mobile_no', `blood_Group` = '$Blood', `date_of_birth` = '$dateOfBirth' , `modified` = '$modified' WHERE `id` = $id";
if ($conn->query($queryText)) {
  $alert = '<span class="alert_suc">Update Seccessfully!</span>';
} else {
  $alert = '<span class="alert_err">Failed To Update!</span>';
}





}
