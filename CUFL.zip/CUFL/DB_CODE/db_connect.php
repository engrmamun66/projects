<?php
date_default_timezone_set("Asia/Dhaka");

function createDatabase()
{
    // Create connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $conn = new mysqli($servername, $username, $password);
    // Create database
    $sql = "CREATE DATABASE cufl";

    if ($conn->query($sql) === TRUE) {
        // echo "Database created successfully";
    }
    CloseCon($conn);
} // End this function


function create_Students_Table()
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "cufl";
    $conn = new mysqli($servername, $username, $password, $db);

    // creating table automatic
    $table_name = "Students_Table";

    // Checking is table exits?
    if ($conn->query("SHOW TABLES LIKE '$table_name'") != $table_name) {

        $sql = "CREATE TABLE `students_table` (
          `id` int(11) NOT NULL AUTO_INCREMENT UNIQUE,
          `email` varchar(255) NOT NULL UNIQUE,
          `name` varchar(100) NOT NULL,
          `fb_id_name` varchar(255),
          `batch` int(20) NOT NULL,
          `house_no` varchar(255),
          `current_workplace` varchar(255),
          `mobile_no` varchar(255) NOT NULL,
          `blood_Group` varchar(255),
          `date_of_birth` date NOT NULL,
          `created` datetime NULL DEFAULT current_timestamp(),
          `modified` datetime NULL,
          PRIMARY KEY (`id`)
        ) AUTO_INCREMENT = 1
        ENGINE=InnoDB CHARACTER SET=utf8 ;";
        // SET time_zone = '+06:00';";

        if ($conn->query($sql) === true) {
            // echo "Table created successfully.";
        }
    }

}// End function


function OpenCon()
{

    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    // $dbuser = "leaperdev";
    // $dbpass = "Wpz70wjglcdMX7JO";
    $db = "cufl";

    $conn = new mysqli($dbhost, $dbuser, $dbpass, $db) or die("Connect failed: %s\n" . $conn->error);
    $conn->set_charset("utf8");
    return $conn;
}


function CloseCon($conn)
{
    $conn->close();
}
