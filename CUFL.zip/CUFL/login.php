<?php
session_start();
if (!empty($_POST['login'])) {
    if (($_POST['username'] == 'cufl_admin') && ($_POST['pass'] == 'cufl_memmber_20#@1')) {
        $_SESSION['username'] = $_POST['username'];
        header("Location: index.php");
    } else {
        $error_msg = 'Invalid username or password';
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Account Login</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/login.css">

</head>
<body>

<div class="limiter">
    <div class="container-login100">
        <div class="wrap-login100 p-b-160 p-t-50">
            <form class="login100-form validate-form" method="post">
                <div class="login100-form-title p-b-43" style="margin-bottom: 20px;">
                    Account Login
                </div>
                <?php if (!empty($error_msg)) { ?>
                    <div style="color: red;width: 100%;margin-bottom: 20px;text-align: center;"><?php echo $error_msg; ?></div>
                <?php } ?>

                    <div class="wrap-input100 rs1 validate-input" data-validate="Username is required">
                        <input class="input100" type="text" name="username">
                        <span class="label-input100">Username</span>
                    </div>


                    <div class="wrap-input100 rs2 validate-input" data-validate="Password is required">
                        <input class="input100" type="password" name="pass">
                        <span class="label-input100">Password</span>
                    </div>

                <div class="container-login100-form-btn">
                    <button class="login100-form-btn" name="login" type="submit" value="login">
                        Sign in
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="assets/js/login.js"></script>

</body>
</html>