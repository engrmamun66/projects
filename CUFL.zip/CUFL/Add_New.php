<?php
// session_start();
// date_default_timezone_set('Asia/Dhaka');
// if (empty($_SESSION['username'])) {
//     header("Location: login.php");
// }
// require ("DB_CODE/db_connect.php");
// require ("Classes/PHPExcel/IOFactory.php");

// createDatabase();
// create_Students_Table();
// $conn = OpenCon();


// include ("Controllers/addNewController.php");


session_start();
require("include/cufl.php");
if (!empty($_POST['login'])) {
  $cuflObj = new CUFL();
  $result = $cuflObj->addnew($_POST);
}
$alert = ""
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>স্মৃতিতে সিইউএফএল এর সদস্য তথ্য</title>
  <link rel="stylesheet" type="text/css" href="assets/css/mystyle.css">
  <?php include("Controllers/Script&StyleSheetsController.php"); ?>
</head>

<body>
  <!-- start top-nav -->
  <?php include("templates/topNav.php") ?>
  <!-- End top-nav -->


  <!-- start body content -->
  <br>
  <br>
  <br>
  <br>


  <div class="body-content2">
    <!-- <h3 align="center">স্মৃতিতে সি.ইউ.এফ.এল পরিবারের পক্ষ হতে আপনাকে স্বাগতম</h3> -->
    <div class="addStdForm">
      <form action="Add_New.php" method="post">
        <div class="formHeader">
          <h3>ADD NEW STUDENT IFORMATION</h3>
        </div>
        <hr> <br>

        <?php if (!empty($result)) { ?>
          <div <?php if ($result['status']) { ?> style="color: green;width: 100%;margin-bottom: 20px;text-align: center;" <?php } else { ?>style="color: #d0d0d0;width: 100%;margin-bottom: 20px;text-align: center;" <?php } ?>>
            <?php echo $result['message']; ?>
          </div>
        <?php } ?>


        <div class="formBody">


          <div class="stdInput">
            <label for="name">Name: <span class="required">*</span></label>
            <input class="" name="name" type="text" placeholder="" autocomplete="on" required>
          </div>


          <div class="stdInput">
            <label for="email">Email Address: <span class="required">*</span></label>
            <input class="" name="email" type="text" placeholder="" autocomplete="on" required>
          </div>


          <div class="stdInput">
            <label for="mobile">Mobile No: <span class="required">*</span></label>
            <input class="" name="mobile" type="text" placeholder="" autocomplete="on" required>
          </div>

          <div class="stdInput">
            <label for="facebook">Facebook Profile: </label>
            <input class="" name="facebook" type="text" placeholder="" autocomplete="on">
          </div>

          <div class="stdInput">
            <label for="batch">SSC Batch: <span class="required">*</span></label>
            <input class="" name="batch" type="text" placeholder="" autocomplete="on" required pattern="[0-9][0-9][0-9][0-9]">
          </div>

          <div class="stdInput">
            <label for="house_no">House No(CUFL): </label>
            <input class="" name="house_no" type="text" placeholder="" autocomplete="on">
          </div>

          <div class="stdInput">
            <label for="address">Current Place: </label>
            <input class="" name="address" type="text" placeholder="" autocomplete="on">
          </div>



          <!-- <div class="stdInput"> -->
          <div class="stdInput">
            <label for="Blood">Blood Group: </label>
            <select class="" name="blood">
              <!-- <option value="0">--Select Blood Group--</option> -->
              <option value="A+">A+</option>
              <option value="A-">A-</option>
              <option value="B+">B+</option>
              <option value="B-">B-</option>
              <option value="AB+">AB+</option>
              <option value="AB-">AB-</option>
              <option value="O+">O+</option>
              <option value="O-">O-</option>
            </select>
          </div>
          <!-- </div> -->

          <div class="stdInput">
            <label for="birth">Date of birth: <span class="required">*</span></label>
            <input class="" name="birth" type="date" placeholder="Required*" autocomplete="on" required>
          </div>
          <br>
          <div class="stdInput">
            <span> <?php echo $alert; ?> </span>
            <a class="gohome" href="index.php"><i class="fa fa-home" aria-hidden="true"></i> HOME</a>
            <input id="myInput" class="buttoninForm button3" type="submit" value="SAVE DATA" name="login">


          </div>
        </div>
      </form>
    </div>






</body>

</html>
</div>
<!-- End table -->

</div>
<!-- End -->

</body>

</html>