<?php
session_start();
if (empty($_SESSION['username'])) {
    header("Location: login.php");
}
require ("DB_CODE/db_connect.php");
require ("Classes/PHPExcel/IOFactory.php");

createDatabase();
create_Students_Table();
$conn = OpenCon();


include ("Controllers/EditbyidController.php");




?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CUFL-[Add Student]</title>
  <link rel="stylesheet" type="text/css" href="assets/css/mystyle.css">
  <?php include ("Controllers/Script&StyleSheetsController.php"); ?>
</head>
<body>
  <!-- start top-nav -->
  <?php include ("templates/topNav.php") ?>
  <!-- End top-nav -->


  <!-- start body content -->
      <br>
      <br>
      <br>
      <br>


    <div class="body-content2">
      <div class="addStdForm">
        <form action="EditById.php" method="post">
          <div class="formHeader">
            <h3><i class="fa fa-id-card-o" aria-hidden="true"></i> <?php if(isset($DataArray['name'])){echo $DataArray['name'];} ?></h3>
            <p class="small">
              Created ➤ <?php if(isset($DataArray['created'])){echo $DataArray['created'];} ?>
              <?php if(isset($DataArray['modified']) && strlen($DataArray['modified'])>0){echo "<br>Last Modified ➤ ".$DataArray['modified'];} ?>
            </p>
          </div>
          <hr> <br>

            <div class="formBody">

              <!-- A hidden textbox -->
              <div style="display:none;">
                <input class="" name="id" type="text" placeholder="id" autocomplete="off" required value="<?php if(isset($DataArray['id'])){echo $DataArray['id'];} ?>">
              </div>

              <div class="stdUpdate">
                <label for="email">Email Address: <span class="required">*</span></label>
                <input class="" name="email" type="text" placeholder="" autocomplete="off" required value="<?php if(isset($DataArray['email'])){echo $DataArray['email'];} ?>">
              </div>

              <div class="stdUpdate">
                <label for="name">Name: <span class="required">*</span></label>
                <input class="" name="name" type="text" placeholder="" autocomplete="off" required value="<?php if(isset($DataArray['name'])){echo $DataArray['name'];} ?>">
              </div>

              <div class="stdUpdate">
                <label for="Facebook_Profile">Facebook Profile: </label>
                <input class="" name="Facebook_Profile" type="text" placeholder="" autocomplete="off" value="<?php if(isset($DataArray['fb_id_name'])){echo $DataArray['fb_id_name'];} ?>">
              </div>

              <div class="stdUpdate">
                <label for="Batch">Batch: <span class="required">*</span></label>
                <input class="" name="Batch" type="text" placeholder="" autocomplete="off" required pattern="[0-9][0-9][0-9][0-9]" value="<?php if(isset($DataArray['batch'])){echo $DataArray['batch'];} ?>">
              </div>

              <div class="stdUpdate">
                <label for="houeNo">House No: </label>
                <input class="" name="houeNo" type="text" placeholder="" autocomplete="off" value="<?php if(isset($DataArray['house_no'])){echo $DataArray['house_no'];} ?>">
              </div>

              <div class="stdUpdate">
                <label for="currentPlace">Current Place: </label>
                <input class="" name="currentPlace" type="text" placeholder="" autocomplete="off" value="<?php if(isset($DataArray['current_workplace'])){echo $DataArray['current_workplace'];} ?>">
              </div>

              <div class="stdUpdate">
                <label for="mobile_no">Mobile No: <span class="required">*</span></label>
                <input class="" name="mobile_no" type="text" placeholder="" autocomplete="off" required value="<?php if(isset($DataArray['mobile_no'])){echo $DataArray['mobile_no'];} ?>">
              </div>

              <!-- <div class="stdUpdate"> -->
                <div class="stdUpdate">
                  <label for="Blood">Blood Group: </label>
                  <select class="" name="Blood">
                    <option value="0">--Select Blood Group--</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <?php if(isset($DataArray['blood_Group'])){
                      echo "<option value='". $DataArray['blood_Group']."' selected>".$DataArray['blood_Group']."</option>";
                    } ?>
                  </select>
                </div>
              <!-- </div> -->

              <div class="stdUpdate">
                <label for="dateOfBirth">Date of birth: <span class="required">*</span></label>
                <input class="" name="dateOfBirth" type="date" placeholder="Required*" required  value="<?php echo $DataArray['date_of_birth'];?>">
                <?php if (isset($DataArray['date_of_birth'])){echo "<br><small>Exiting Date ➤ ".$DataArray['date_of_birth']."</small>";}?>
              </div>
              <br>
              <div class="stdUpdate">
                <span> <?php echo $alert; ?>  </span>
                <a class="gohome" href="index.php"><i class="fa fa-home" aria-hidden="true"></i> HOME</a>
                <input id="myInput" class="buttoninForm button3" type="submit" value="UPDATE DATA" name="StdFormUpdate">


              </div>
            </div>
        </form>
      </div>






</body>
</html>
    </div>
    <!-- End table -->

  </div>
<!-- End -->

</body>
</html>
