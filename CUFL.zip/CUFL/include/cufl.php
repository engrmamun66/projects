<?php

class CUFL
{
    public $conn;
    public $limit = 50;
    public $pages_to_click = 5;

    public function __construct()
    {

    }

    public function db_connection()
    {
        date_default_timezone_set("Asia/Dhaka");
        $dbhost = "localhost";
        $dbuser = "root";
        $dbpass = "";
        // $dbuser = "leaperdev";
        // $dbpass = "Wpz70wjglcdMX7JO";
        $db = "cufl";
        $this->conn = new mysqli($dbhost, $dbuser, $dbpass, $db) or die("Connect failed: %s\n" . $this->conn->error);
        $this->conn->set_charset("utf8");
        return $this->conn;

    }

    public function search($page = 1)
    {
        $this->db_connection();
        $txt_1 = 'SELECT * FROM `students_table` WHERE `id`> 0 ';
        $sortBy = 'name';
        foreach ($_SESSION['search'] as $k => $v) {
            if ($v != 'Search' & strlen($v) > 0) {
                $k == "email" ? $txt_1 = "$txt_1 AND email LIKE '%$v%' " : '';
                $k == "batch" ? $txt_1 = "$txt_1 AND batch ='$v' " : '';
                $k == "name" ? $txt_1 = "$txt_1 AND name LIKE '%$v%' " : '';
                $k == "blood" ? $txt_1 = "$txt_1 AND blood_Group ='$v' " : '';
                $k == "mobile" ? $txt_1 = "$txt_1 AND mobile_no LIKE '%$v%' " : '';
                $k == "address" ? $txt_1 = "$txt_1 AND current_workplace LIKE '%$v%' " : '';
                //$k == "orderby" ? $txt_1 = "$txt_1 ORDER BY $sortBy $v" : '';

            }
        }
        $txt2 = chop($txt_1);
        $finalText = $this->removeExtraSpace($txt_1); // with removing white space from left and ringt\
        $offset = ($page == 1) ? 0 : $this->limit * ($page - 1);
        $totalRows = $this->conn->query($finalText);
        $finalText = $finalText . ' ORDER BY name ASC ' . 'limit ' . $this->limit . ' offset ' . $offset;
        $searchResults = $this->conn->query($finalText);

        if (isset($searchResults->num_rows)) {
            $searchRow = $totalRows->num_rows;
            $row = $searchRow;
            $studentsData = $searchResults->fetch_all();
        } else {
            $searchRow = 0;
            $studentsData = [];
        }
        return ['data' => $studentsData, 'total' => $searchRow];
    }

    public function all($page = 1)
    {
        $this->db_connection();
        $txt_1 = 'SELECT * FROM `students_table` WHERE `id`> 0 ';
        $totalRows = $this->conn->query($txt_1);
        $sortBy = 'name';
        $txt2 = chop($txt_1);
        $finalText = $this->removeExtraSpace($txt_1); //
        $page = empty($page) ? 1 : $page;
        $offset = ($page == 1) ? 0 : $this->limit * ($page - 1);
        $finalText = $finalText . ' ORDER BY name ASC ' . 'limit ' . $this->limit . ' offset ' . $offset;
        $searchResults = $this->conn->query($finalText);
        if (isset($searchResults->num_rows)) {
            $searchRow = $totalRows->num_rows;
            $row = $searchRow;
            $studentsData = $searchResults->fetch_all();
        } else {
            $searchRow = 0;
            $data = [];
        }
        return ['data' => $studentsData, 'total' => $searchRow];
    }

    function pagination($page = 1, $total)
    {
        $page = empty($page) ? 1 : $page;
        $target_page = 1;
        $page == 1 ? $target_page = 1 : $target_page = (($page * $this->pages_to_click) - $this->pages_to_click);

        $Allpages = ceil($total / $this->limit);
        $target_page -= 1;
        $page > 1 ? $previousPage = $page - 1 : $previousPage = $page;  //Previous Page
        $page < $Allpages ? $nextPage = $page + 1 : $nextPage = $page; //Next Page
        $page > 1 ? $page -= 1 : $page;
        return ['page' => $page, 'Allpages' => $Allpages, 'target' => $target_page,
            'pages_to_click' => $this->pages_to_click, 'nextPage' => $nextPage, 'previousPage' => $previousPage];
// }
    }

    function removeExtraSpace($text)
    {
        $text = str_replace("    ", "  ", $text);
        $text = str_replace("   ", "  ", $text);
        $text = str_replace("  ", " ", $text);
        return chop($text);
    }


    function addnew($data)
    {
        $this->db_connection();
        $checkSQL = "Select * from students_table where email = '" . trim($_POST['email']) . "'";
        $existing = $this->conn->query($checkSQL);
        $result = $existing->fetch_assoc();
        if (!empty($result)) {
            return ['status' => false, 'message' => 'There is already one member exists using this email address.'];
        }
        $birth = date('Y-m-d 00:00:00', strtotime($_POST['birth']));
        $queryText = "INSERT INTO `students_table`(`email`, `name`, `fb_id_name`, `batch`, `house_no`, `current_workplace`, `mobile_no`, `blood_Group`, `date_of_birth`, `created`) 
                        VALUES('" . trim($_POST['email']) . "', '" . trim($_POST['name']) . "', 
                        '" . trim($_POST['facebook']) . "', 
                        '" . trim($_POST['batch']) . "', 
                        '" . trim($_POST['house_no']) . "', 
                        '" . trim($_POST['address']) . "', 
                        '" . trim($_POST['mobile']) . "', 
                        '" . trim($_POST['blood']) . "', 
                        '" . $birth . "', 
                        '" . date('Y-m-d H:i:s') . "')";
        $this->conn->query($queryText);
        return ['status'=>true,'message'=> 'Thank you, your details are saved.'];
    }

}







