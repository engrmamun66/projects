<b>Assalamu alaikum</b><br>SMTP mail program done with cofiguration <b>Sender</b> account.<br>
<img src="*/assets/img/happlyBirthDay.Jpg" alt="Happy Birth Day Image" width="500" height="600">
