<div class="searhSection">
  <form action="index.php" method="POST">
    <p><i class="fa fa-search" aria-hidden="true"></i> Search</p>
    <!-- <p>THis is some textTHis is some textTHis is some textTHis is some textTHis is some textTHis is some textTHis is some textTHis is some textTHis is some textTHis is some textTHis is some text</p> -->
    <div class="divline-1">
      <input class="secAlign " name="email" type="text" placeholder="Email" autocomplete="on" value="<?php if(isset($_POST['email'])){echo $_POST['email'];} ;?>">
      <input class="secAlign " name="batch" type="text" placeholder="Batch" autocomplete="on" value="<?php if(isset($_POST['batch'])){echo $_POST['batch'];} ;?>">
    </div>

    <div class="divline-2">
      <input class="secAlign " name="name" type="text" placeholder="Name" autocomplete="on" value="<?php if(isset($_POST['name'])){echo $_POST['name'];} ;?>">

    <select class="secAlign" name="blood">
        <option value=""  <?php if(isset($_POST['blood']) && $_POST['blood'] =='' ) {echo "selected";} ;?>>--Select Blood Group--</option>
        <option value="A+" <?php if(isset($_POST['blood']) && $_POST['blood'] =='A+' ) {echo "selected";} ;?>>A+</option>
        <option value="A-"<?php if(isset($_POST['blood']) && $_POST['blood'] =='A-' ) {echo "selected";} ;?>>A-</option>
        <option value="B+" <?php if(isset($_POST['blood']) && $_POST['blood'] =='B+' ) {echo "selected";} ;?>>B+</option>
        <option value="B-" <?php if(isset($_POST['blood']) && $_POST['blood'] =='B-' ) {echo "selected";} ;?>>B-</option>
        <option value="AB+" <?php if(isset($_POST['blood']) && $_POST['blood'] =='AB+' ) {echo "selected";} ;?>>AB+</option>
        <option value="AB-" <?php if(isset($_POST['blood']) && $_POST['blood'] =='AB-' ) {echo "selected";} ;?>>AB-</option>
        <option value="O+" <?php if(isset($_POST['blood']) && $_POST['blood'] =='O+' ) {echo "selected";} ;?>>O+</option>
        <option value="O-" <?php if(isset($_POST['blood']) && $_POST['blood'] =='O-' ) {echo "selected";} ;?>>O-</option>
      </select>
    </div>


    <div class="divline-3">
      <input class="secAlign " name="mobile" type="text" placeholder="Moblie" autocomplete="on" value="<?php if(isset($_POST['mobile'])){echo $_POST['mobile'];} ;?>">
        <input class="secAlign " name="address" type="text" placeholder="Address" autocomplete="off" value="<?php if(isset($_POST['address'])){echo $_POST['address'];} ;?>">
        <?php /*<select class="secAlign" name="orderby">
        <option value="ASC"  <?php if(isset($_POST['blood']) && $_POST['orderby'] =='ASC' ) {echo "selected";} ;?>>ASC</option>
        <option value="DESC"  <?php if(isset($_POST['blood']) && $_POST['orderby'] =='DESC' ) {echo "selected";} ;?>>DESC</option>
      </select> */?>
    </div>

    <div class="divline-4">
      <input class="secAlign Clearbtn button3 extrastyleBtn" type="submit" value="Search" name="Search_submit">
      <a  class="secAlign Clearbtn button2"  href="index.php">Clear</a>        
        <div class="showTotal">
          <span class="showCount">Result - items <b>:</b> <?php echo $row; ?></span>
        </div>
    </div>
  </form>
  <br>
  <!-- <br>  <br>    <br> <br> <br> <br> -->
    <!-- <input class="secAlign buttoninForm button3 extrastyleBtn" type="submit" value="Clear"> -->


</div>
