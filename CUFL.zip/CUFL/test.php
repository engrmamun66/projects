<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

$message = 'My test message';
$mobiles = '8801534406051,01700769654';
//$url = "http://api.icombd.com/api/v1/campaigns/sendsms/plain?username=planit&password=planit@051&sender=03590001944&text=" . $message . "&to=" . $mobiles;
//$cURLConnection = curl_init();
//curl_setopt($cURLConnection, CURLOPT_URL, $url);
//curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
//$phoneList = curl_exec($cURLConnection);
//curl_close($cURLConnection);

$curl = curl_init();

curl_setopt_array($curl, array(
    CURLOPT_URL => "http://api.icombd.com/api/v1/campaigns/sendsms/plain",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => "user=planit&password=planit@051&sender=03590001944&SMSText=test%20sms%20from%20planit&GSM=8801700769654",
    CURLOPT_HTTPHEADER => array(
        "Content-Type: application/x-www-form-urlencoded"
    ),
));

$response = curl_exec($curl);

curl_close($curl);


print_r("<pre>");print_r($response);print_r("</pre>");