<?php

// Example:1
$string = "PHP is the web php scripting language of choice . ? 522 less than 825 i ";
print_r (preg_split("/(web|of)/", $string, -1, PREG_SPLIT_NO_EMPTY));


$string = "PHP";

// Example:2
if (preg_match_all("/./", $string, $matches)) {
    $im = implode("----", $matches[0]);
    print_r($im);
}


echo "\n";
