<?php

use function PHPSTORM_META\type;

$html ='
<body>
    <div class="container">
        <header class="header">
            <img src="./Lays_brand_logo.png" alt="logo">
            <ul>
                <li>One</li>
                <li>One</li>
                <li>One</li>
            </ul>
        </header>
        <aside>This is sidebar</aside>
        <main> Main Side </main>
        <footer>This is footer</footer>
    </div>
</body>

';

$html = preg_replace("/\n/im", " ", $html);
$html = preg_replace("/\t/im", " ", $html);
$html = preg_replace("/\s{4}/im", " ", $html);
$html = preg_replace("/\s{3}/im", " ", $html);
$html = preg_replace("/\s{2}/im", "", $html);
$patterns = array("/(\n)/im","/(\t)/im","/(\s{4})/im","/(\s{3})/im", "/(\s{2})/im");
$replaceMents = array(" "," "," "," ", " ");

if(preg_replace($patterns, $replaceMents, $html)){
    $html = $html;
}
// print_r($plainText);


echo "\n";
if(preg_match_all("/<[^\/].*?>/im", $html, $plainHTML)){
    print_r($plainHTML);
    echo "\n"; 
}






