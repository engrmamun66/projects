<?php
echo "<pre>";

// https://www.youtube.com/watch?v=3RlDZEa6gW8
// https://www.youtube.com/watch?v=YjtsWHDnPwE

/**
 * META CHARECTERS (need to be escaped) -- Not no need to escap when these use in [ ] or ( )
 * [{()\^$|?*+.
 * 
 * 
 * i = case insensetive
 * m = multiline
 * u = Match with full unicode
 * x = ignore white space
 * S = Dot matches newline
 * 
 * \w = chars selector
 * \W = special chars selector
 * 
 * \d = digit selector
 * \D = without digit selector
 * 
 * \s = space selector
 * \S = without space selector
 * 
 * \b = boundari selector (bounday means, je pase \b use korbo se pase word suru ba sesh hote hobe)
 * \B = Not boundari selector (Not bounday means, je pase \B use korbo se pase word suru ba sesh hoya jabena)
 * 
 * \n = new line
 * \t = tab
 * \v = verticle tab * 
 * 
 * ////////////////////////////////////
 * ////////////////////////////////////
 * ////////////////////////////////////
 * 
 * . = single char(Any thing)
 * * = 0 or more
 * + = 1 or more
 * ? = 0 or one
 * ^ = start with if use start of pattern and work as 'not' when it use in [ ]
 * 
 * () = grouping, passing as optional part use question mark. Ex: ()? ----- but only () is required
 * {3} = Exact Number/limit-Char limit
 * {3,5} = range of numbers/limit-Char(minimum, maximum) limit
 * {3,} = minimum number/limit-Char to infinite
 * ------Note '{' or '}' also use as not char in pattern
 * [] = define range a-z or A-Z or a-j or 1-5 or charecters phdg etc
 * 
 * 
 * //https://youtu.be/YjtsWHDnPwE?t=1208
 * *n = Greedy Match (n er jaygate jekono char/cahrs/digits/speecialChar boste pare)
 * +n = Greedy Match (n er jaygate jekono char/cahrs/digits/speecialChar boste pare)
 * *?n = Lazy Match (n er jaygate jekono char/cahrs/digits/speecialChar boste pare)
 * +?n = Lazy Match (n er jaygate jekono char/cahrs/digits/speecialChar boste pare)
 * 
 * ?=n = positive Lookahead (n er jaygate jekono kichu hote pare)
 * ?!n = Negative Lookahead (n er jaygate jekono kichu hote pare)
 * ?<=n = positive Lookbehind (n er jaygate jekono kichu hote pare)
 * ?<!n = Negatve Lookbehind (n er jaygate jekono kichu hote pare)
 * 
 */

$string = "PHP is the web php scripting language of choice . ? 522 less than 825 i ";
$exp = preg_match("/PHP/", $string, $matched);
$exp = preg_match_all("/php/i", $string, $matched);
$exp = preg_match_all("/php|web|the/i", $string, $matched);
$exp = preg_match_all("/522|825/i", $string, $matched); // search by or(|) codition
$exp = preg_match_all("/[e]/i", $string, $matched); // sarching all e in string
$exp = preg_match_all("/[ew]/i", $string, $matched); // sarching all e and w in string
$exp = preg_match_all("/[ei][b]/i", $string, $matched); // sarching all e and i AND then must keep b in string
$exp = preg_match_all("/[^phw5]/i", $string, $matched); // sarching all where not p and h and w and 5 in string
$exp = preg_match_all("/[a-j]/i", $string, $matched); // sarching all where a to j char in string
$exp = preg_match_all("/[a-jA-J]/", $string, $matched); // sarching all where a to j char in string By canse sensetive and insensetive
$exp = preg_match_all("/[a-j0-9]/", $string, $matched); // sarching where a to j and 0 to 9
$exp = preg_match_all("/w[e]b/", $string, $matched); // sarching e, after w and before b
$exp = preg_match_all("/[^a-j0-9]/", $string, $matched); // sarching where not a to j and 0 to 9
$exp = preg_match_all("/[0-9]/", $string, $matched); // sarching all where a to j char in string By canse sensetive and insensetive

$exp = preg_match_all("/\W/", $string, $matched); // \w select all charecter
$exp = preg_match_all("/\W/", $string, $matched); // \W select special charecters

$exp = preg_match_all("/\d/", $string, $matched); // \d select all digits
$exp = preg_match_all("/\D/", $string, $matched); // \D select all without digits, 

$exp = preg_match_all("/\s/", $string, $matched); // \D select all space
$exp = preg_match_all("/\S/", $string, $matched); // \D select all without space

// Boundari selector
$exp = preg_match_all("/\b/", $string, $matched); // \b assert position at a word boundary
$exp = preg_match_all("/\bPHP/b/i", $string, $matched); // finding PHP as a word
$exp = preg_match_all("/\ba/b/i", $string, $matched); // finding a as a word
$exp = preg_match_all("/\bthe/b/i", $string, $matched); // finding the as a word
$exp = preg_match_all("/\b825/b/i", $string, $matched); // finding 825 as a word

$exp = preg_match_all("/\bph./b/i", $string, $matched); // finding 1 char after ph
$exp = preg_match_all("/\b.hp/b/i", $string, $matched); // finding 1 char before hp

// Escape special charecters
// --- if you want to find special chars, jus type before backslash(\)
// .  ( [ ] ) + * ^ | $ ------- Note '{' or '}' also use as not char in pattern
$exp = preg_match_all("/\?/i", $string, $matched); 

$string = "Jan Januray";
$exp = preg_match_all("/Jan(uray)?/i", $string, $matched); // (anything)? is optional to search

$string = "Jan Januray";
$exp = preg_match_all("/Jan(uray)?/i", $string, $matched); // (anything)? is optional to search

$string = "
        o
        oh
        ohh
        ohhh
        ohhhh
        ohhhhh
        ";
$exp = preg_match_all("/oh{2,5}/i", $string, $matched); // find where before 'o' and 'h' minimum 2 times and maximum 5 times
$exp = preg_match_all("/\d{2,5}/i", $string, $matched); // find where minimum 2 digit and maximum 5 digit
$exp = preg_match_all("/\d{2,}/i", $string, $matched); // find where minimum 2 digit to infinite

$string = "PHP is the web scripting phhhp language scipting of choice.";
$exp = preg_match_all("/s[a-z]*i/i", $string, $matched); // Greedy
$exp = preg_match_all("/s[a-z]*?i/i", $string, $matched); // lazy


$string = "
file.txt
file1.xlsx
file20 ↓ ○.docx
fileabc1.pptx";
$exp = preg_match_all("/file\w*(\W*).(txt|xlsx|docx|pptx)/i", $string, $matched); // find where before 'o' and 'h' minimum 2 times and maximum 5 times

$string = "
I like Toyota 
I like Toyota and Honda and Toyota
I like Toyota and Honda and Honda
";
$exp = preg_match_all("/I like (Toyota) and (Honda) and \1/i", $string, $matched); // find by index postion
$exp = preg_match_all("/I like (Toyota) and (Honda) and \2/i", $string, $matched); // find by index postion


/**
 * ?=n = positive Lookahead (n er jaygate jekono kichu hote pare)
 * ?!n = Negative Lookahead (n er jaygate jekono kichu hote pare)
 * ?<=n = positive Lookbehind (n er jaygate jekono kichu hote pare)
 * ?!=n = Negatve Lookbehind (n er jaygate jekono kichu hote pare)
 */

$string = "
bill paid
bill not paid
bill paid
bill not paid
";
//positive Lookahead
$exp = preg_match_all("/bill(?=\spaid)/i", $string, $matched); // finding bill where space and paid after bill
// Negative Lookahead
$exp = preg_match_all("/bill(?!\spaid)/i", $string, $matched); // finding bill where not space and paid after bill

//positive Lookbehind
$exp = preg_match_all("/(?<=bill\s)spaid/i", $string, $matched); // finding bill where space and paid after bill
// Negatve Lookbehind
$exp = preg_match_all("/(?!=bill\s)spaid/i", $string, $matched); // finding bill where not space and paid after bill








if($exp){
    echo "Yes found matched"; 
    
}else{
    echo "Not matched";
}

print_r($matched);






?>
