<?php

$string = "{startDate} = 1999-5-10";
$pattern = array("/(19|20)-(\d{1,2})-(\d{1,2})/i", "/^\s*{(\w+)}/i");
$replacement = ["$4/$3:/$1:$2", "$1"];
echo preg_replace($pattern, $replacement, $string);