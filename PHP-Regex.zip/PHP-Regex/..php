<?php

$string = "PHP is the web php scripting language of choice . ? 522 less than 825 i ";



$string = "PHP";
if (preg_match_all ("/./i", $string, $matches)){
    
    print_r (implode('-', $matches[0]));
}
echo "\n";