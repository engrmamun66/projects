<?php
session_start();
require 'connection.php';

?>
<html>
<head>

</head>
<body>
<div style="background-color: #ccc; margin: auto; width: 50%; padding: 15px">
    <h2>Import Excel File into MySQL Database using PHP</h2>

    <div class="outer-container">
        <form action="upload.php" method="post"
              name="frmExcelImport" id="frmExcelImport" enctype="multipart/form-data">
            <div>
                <label>Choose Excel
                    File</label> <input type="file" name="file"
                                        id="file" accept=".xls,.xlsx">
                <button type="submit" id="submit" name="import"
                        class="btn-submit">Import
                </button>

            </div>

        </form>

    </div>
</div>


<?php

if (isset($_SESSION['table_name'])) {
    $sqlSelect = "SELECT * FROM " . $_SESSION['table_name'];
    $result = mysqli_query($conn, $sqlSelect);
    $total = mysqli_num_rows($result);
    if ($total) {
        echo $total." Records inserted succesfully in ".$_SESSION['table_name']." <br>";
    } else {
        echo "0 results <br>";
    }
    unset($_SESSION['table_name']);
}
?>
</body>
</html>