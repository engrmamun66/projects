<?php

$database = 'kitabghor';
$user = 'root';
$password = "";
$host = "localhost";
$conn = mysqli_connect($host,$user,$password, $database);