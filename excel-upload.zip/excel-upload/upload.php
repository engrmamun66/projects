<?php
session_start();
require_once 'vendor/autoload.php';
require 'connection.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;


if (isset($_POST["import"])) {

    $allowedFileType = [
        'application/vnd.ms-excel',
        'text/xls',
        'text/xlsx',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ];

    if (in_array($_FILES["file"]["type"], $allowedFileType)) {

        $targetPath = 'uploads/' . $_FILES['file']['name'];
        move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);
        $ext = pathinfo($targetPath, PATHINFO_EXTENSION);
        $tableName = strtolower(basename($targetPath, ".".$ext));
        $_SESSION['table_name'] = $tableName;

        $Reader = new Xlsx();
        $spreadSheet = $Reader->load($targetPath);
        $excelSheet = $spreadSheet->getActiveSheet();
        $spreadSheetAry = $excelSheet->toArray();
        $columns = $excelSheet->getHighestDataColumn();
        $columns = Coordinate::columnIndexFromString($columns);
        $sheetCount = count($spreadSheetAry);

        $dataRows = []; $tableColumns = [];
        $in = 1;
        $truncate = 'TRUNCATE TABLE '.$tableName;
        if (mysqli_query($conn, $truncate)) {
            for ($row = 0; $row < $sheetCount; $row++) {
                $dataColumns = [];
                for ($col = 0; $col < $columns; $col++) {
                    if (!$row) {
                        $tableColumns[] = $spreadSheetAry[$row][$col];
                    } else {
                        $dataColumns[] = $spreadSheetAry[$row][$col];
                    }
                }
                if ($row) {
                    $dataRows[] = $dataColumns;
                    if (!empty($dataRows)) {
                        $query = "insert into " . $tableName . "(";
                        $count = 1;
                        foreach ($tableColumns as $item) {
                            $query .= $item;
                            if ($count < $columns) $query .= ", ";
                            $count++;
                        }
                        $query .= ") values( ";
                        for ($i = 0; $i < $columns; $i++) {
                            $value = mysqli_real_escape_string($conn, $dataColumns[$i]);
                            $query .= "'" . $value . "'";
                            if ($i < $columns - 1) $query .= ", ";
                        }
                        $query .= ")";

                        if (mysqli_query($conn, $query)) {
//                        echo "New record created successfully $in \n <br> <br/>";
//                        $in++;
                        } else {
                            echo "Error: " . $query . "<br>" . mysqli_error($conn);
                        }


                    }
                }
            }
        }
        header("Location: index.php");
        exit();
    } else {
        $type = "error";
        $message = "Invalid File Type. Upload Excel File.";
    }
}
?>