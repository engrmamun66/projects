<?php
namespace inc;


class Climb {
    function get_name() {
      return 222;
    }
  }


  