<?php
namespace inc;

class Notfound{
   public $error = "Sorry! Not found this class";
}