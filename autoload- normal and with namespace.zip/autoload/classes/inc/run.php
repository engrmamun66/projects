<?php
namespace inc;

class Run{
    protected $can_run = false;
    /**
     * Create a new run instance
     */
     
     public function __construct($can_run)
     {
         $this->can_run = $can_run;
     }
 
     /**
      * Magic method- __to_string
     */
    public function __toString(){
        return $this->can_run ? "Yes, can run!" : "Not run!";
    }
}