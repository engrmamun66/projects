<?php
namespace inc;

class Color{
    protected $can_run = false;
    /**
     * Create a new run instance
     */
     
     public function index($color)
     {
         echo $color;
     }
 
    
}