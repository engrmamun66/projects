<?php



// spl_autoload_register(function($classname){
//     if(file_exists(include_once 'inc/' . $classname . '.php')){
//         include_once 'inc/' . $classname . '.php';
//     } 
// });


// or 


// function autoload_one($classname){
//     if(file_exists(include_once 'inc/' . $classname . '.php')){
//         include_once 'inc/' . $classname . '.php';
//     }  
// }
// spl_autoload_register('autoload_one');


//or

// with name space
spl_autoload_register(function($classname){
    if(file_exists(include_once str_replace("\\", "/", $classname) . '.php')){
        include_once str_replace("\\", "/", $classname) . '.php';
    }
});
