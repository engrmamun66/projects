<?php

use inc\Climb as mam;
use inc\Run as rr;
use inc\Color as color;

require_once 'classes/autoload.php';

$climb = new mam();
$run = new rr(false);
$color = new color();

echo "<pre>";
echo $climb->get_name();
echo "<br>";
echo $run;
echo "<br>";
echo $color->index("red");
